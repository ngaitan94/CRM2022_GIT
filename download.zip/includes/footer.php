<script src="https://smtpjs.com/v3/smtp.js"></script>
<script src="./js/scripts.js" async></script>

</body>
</html>